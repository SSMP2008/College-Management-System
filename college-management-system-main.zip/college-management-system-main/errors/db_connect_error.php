<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Internal Server Error</title>
    <link rel="icon" type="image/x-icon" href="../images/1.png">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            text-align: center;
        }

        .error-container {
            max-width: 600px;
            width: 100%;
        }

        .error-image {
            margin: 0px 20px;
            max-width: 90%;
            height: auto;
        }

        h1 {
            color: #dc3545;
        }

        p {
            color: #343a40;
        }

        a {
            color: #007bff;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <div class="error-container">
        <img src="../images/attention.png" alt="Error Image" width="400px" height="400px" class="error-image">
        <h1>Internal Server Error</h1>
        <p>Sorry, something went wrong on our end. We're working to fix it. Please try again later.</p>
        <!-- <p>If you believe this is a mistake, you can <a href="#">contact support</a>.</p> -->
    </div>
</body>

</html>
